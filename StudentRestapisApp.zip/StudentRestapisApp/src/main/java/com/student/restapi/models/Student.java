package com.student.restapi.models;

import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.*;

@Entity
@Table(name = "students")
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "name")
	private String name;
	
	@JsonFormat(pattern = "dd/MM/yyyy")
	@Column(name = "date_of_birth")
	private Date date_of_birth;
	
	@JsonFormat(pattern = "dd/MM/yyyy")
	@Column(name = "joining_date")
	private Date joining_date;
	
	@Column(name = "std_class")
	private String std_class;
	
	public Student()
	{
		
	}

	public Student(long id, String name, Date date_of_birth, Date joining_date, String std_class) {
		super();
		this.id = id;
		this.name = name;
		this.date_of_birth = date_of_birth;
		this.joining_date = joining_date;
		this.std_class = std_class;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDate_of_birth() {
		return date_of_birth;
	}

	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	public Date getJoining_date() {
		return joining_date;
	}

	public void setJoining_date(Date joining_date) {
		this.joining_date = joining_date;
	}

	public String getStd_class() {
		return std_class;
	}

	public void setStd_class(String std_class) {
		this.std_class = std_class;
	}
	
	

	
}
