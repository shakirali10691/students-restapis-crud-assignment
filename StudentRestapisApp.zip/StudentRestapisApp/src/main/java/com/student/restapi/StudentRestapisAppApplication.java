package com.student.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentRestapisAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentRestapisAppApplication.class, args);
	}

}
